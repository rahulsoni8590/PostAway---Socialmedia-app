import UserRepository from "./users.repository.js";
import { userModel } from "./users.repository.js";
import bcrypt from "bcrypt"
import jwt from "jsonwebtoken"

export default class UserController{
    constructor(){
        this.userRepository = new UserRepository()
    }

    async signUp(req,res){
        try{
            console.log(req.body)
            const {name,email,password,gender} = req.body;
            const hashedpassword = await bcrypt.hash(password,10);
            const newUser = new userModel({
                name:nam,
                email:email,
                password:hashedpassword,
                gender:gender
                })
                console.log(newUser)
            await this.userRepository.signUp(newUser)
            res.status(201).send(newUser)
        }catch(err){
            console.log(err)
            throw new Error()
        }
    }

    async signIn(req,res){
        const {email,password}= req.body;
        const user = await this.userRepository.findUser(email);
        if(user){
            const verify = bcrypt.compare(password, user.password)
            if(verify){
                const token = jwt.sign({userid:user._id}, process.env.JWT_SECRET_KEY, {expiresIn:"10h"})
                res.status(200).json({
                    token: token,
                    status: "Login Successfull"})
            }else{
                res.status(400).send("Login Failed")
            }
        } else{
            res.status(404).send("User not Found")
        }

    }

    logOut(req,res){
        
    }

    logoutAllDevices(req,res){
        
    }
}


// export const loginUser = (req, res) => {
//     let status = confirmLogin(req.body);
//     if (status) {
//       //  Write your code here to create the JWT token and store it in a cookie named "jwtToken"
//       const token = jwt.sign({userId:status.id,userEmail:status.email},"qmRj5KYfCmkWbFhnYzcoK15HKblrWTjz",{expiresIn:"1h"})
  
//       res
//         .status(200)
//         .cookie("jwt", token, { maxAge: 900000, httpOnly: false })
//         .json({ status: "success", msg: "login successfull", token });
//     } else {
//       res.status(400).json({ status: "failure", msg: "invalid user details" });
//     }
//   };
  